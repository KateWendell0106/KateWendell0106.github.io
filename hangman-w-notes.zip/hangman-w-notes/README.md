# Hangman w/ notes

A Pen created on CodePen.

Original URL: [https://codepen.io/Kathryn-Wendell/pen/dPbNvXR](https://codepen.io/Kathryn-Wendell/pen/dPbNvXR).

